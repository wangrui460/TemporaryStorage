# JXMovableCellTableView
通过长按手势即可移动cell的tableView
##效果图：
![效果图](https://github.com/pujiaxin33/JXMovableCellTableView/raw/master/JXMovableCellTableView.gif)
