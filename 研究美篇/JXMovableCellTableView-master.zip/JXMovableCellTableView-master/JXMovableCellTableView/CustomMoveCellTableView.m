//
//  CustomMoveCellTableView.m
//  JXMovableCellTableView
//
//  Created by jiaxin on 16/2/16.
//  Copyright © 2016年 jiaxin. All rights reserved.
//

#import "CustomMoveCellTableView.h"

@implementation CustomMoveCellTableView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
