//
//  CustomMoveCellTableView.h
//  JXMovableCellTableView
//
//  Created by jiaxin on 16/2/16.
//  Copyright © 2016年 jiaxin. All rights reserved.
//

#import "JXMovableCellTableView.h"

@interface CustomMoveCellTableView : JXMovableCellTableView

@end
